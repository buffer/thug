alert("Foobar");
